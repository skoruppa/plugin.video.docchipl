from resources.lib.routing import router

if __name__ == '__main__':
    router()
